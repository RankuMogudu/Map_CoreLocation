//
//  ViewController.m
//  Map
//
//  Created by fis on 10/01/15.
//  Copyright (c) 2015 fis. All rights reserved.
//

#import "ViewController.h"
#import "DisplayView.h"

@interface ViewController ()

@end

@implementation ViewController



- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.


    locationManager = [[CLLocationManager alloc] init];
   
    [locationManager requestAlwaysAuthorization];

    
    locationManager.distanceFilter = kCLDistanceFilterNone;
    locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    [locationManager startUpdatingLocation];
    NSLog(@"latitude: %f longitude: %f", locationManager.location.coordinate.latitude, locationManager.location.coordinate.longitude);

    MKCoordinateRegion region = { {0.0, 0.0 }, { 0.0, 0.0 } };
	region.center.latitude = locationManager.location.coordinate.latitude;
	region.center.longitude = locationManager.location.coordinate.longitude;
	region.span.longitudeDelta = 0.001f;
	region.span.latitudeDelta = 0.001f;
    [_mapView setMapType:MKMapTypeHybrid];
    [_mapView setRegion:region];

    [_mapView setDelegate:self];

    _mapView.scrollEnabled=YES;
    _mapView.zoomEnabled=YES;

    DisplayView *ann = [[DisplayView alloc] init];
    ann.title = @" Hyderabad ";
    ann.subtitle = @"Maitrivanam Lane";
    ann.coordinate = region.center;
    [_mapView addAnnotation:ann];
    
    CLLocation *loc1=[[CLLocation alloc]initWithLatitude:19.163412 longitude:84.712616];
    CLLocation *loc2=[[CLLocation alloc]initWithLatitude:17.385044 longitude:78.486671];
    
    
    //NSLog(@"%f total distence",[loc1 distanceFromLocation:loc2]);
    CLLocationDistance km = [loc1 distanceFromLocation:loc2]/1000;
    CLLocationDistance mm = [loc1 distanceFromLocation:loc2];
    
    CLLocationCoordinate2D coordinateArray[2];
    coordinateArray[0] = CLLocationCoordinate2DMake(19.163412, 84.712616);
    coordinateArray[1] = CLLocationCoordinate2DMake(17.385044, 78.486671);

    NSLog(@"%f distance in mm",mm);
    NSLog(@"%f distance in km",km);

    self.routeLine = [MKPolyline polylineWithCoordinates:coordinateArray count:2];
    [self.mapView setVisibleMapRect:[self.routeLine boundingMapRect]];
    
    [self.mapView addOverlay:self.routeLine];


}



-(void)locationManager:(CLLocationManager *)manager didChangeAuthorizationStatus:(CLAuthorizationStatus)status {
    
    if (status == kCLAuthorizationStatusAuthorizedWhenInUse) {
        self.mapView.showsUserLocation = YES;
    }
}

-(MKAnnotationView *)mapView:(MKMapView *)mV viewForAnnotation:(id <MKAnnotation>)annotation {
	MKPinAnnotationView *pinView = nil;
	if(annotation != _mapView.userLocation)
	{
		static NSString *defaultPinID = @"com.fortune.pin";
        pinView = (MKPinAnnotationView *)[_mapView dequeueReusableAnnotationViewWithIdentifier:defaultPinID];
        
        if ( pinView == nil ) pinView = [[MKPinAnnotationView alloc]
										  initWithAnnotation:annotation reuseIdentifier:defaultPinID];
		
		pinView.pinColor = MKPinAnnotationColorRed;
		pinView.canShowCallout = YES;
		pinView.animatesDrop = YES;
	}
	else {
		[_mapView.userLocation setTitle:@"I am here"];
	}
	return pinView;
}

-(MKOverlayView *)mapView:(MKMapView *)mapView viewForOverlay:(id<MKOverlay>)overlay
{
    if(overlay == self.routeLine)
    {
        if(nil == self.routeLineView)
        {
            self.routeLineView = [[MKPolylineView alloc] initWithPolyline:self.routeLine];
            self.routeLineView.fillColor = [UIColor redColor];
            self.routeLineView.strokeColor = [UIColor redColor];
            self.routeLineView.lineWidth = 5;
            
        }
        
        return self.routeLineView;
    }
    
    return nil;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
