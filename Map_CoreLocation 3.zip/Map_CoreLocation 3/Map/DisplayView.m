//
//  DisplayView.m
//  Map
//
//  Created by fis on 10/01/15.
//  Copyright (c) 2015 fis. All rights reserved.
//

#import "DisplayView.h"

@implementation DisplayView
@synthesize coordinate,title,subtitle;

@end
